package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.entity.EmployeeDTO;
import com.example.EmployeeManagementSystem.entity.EmployeeProjection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByDepartmentName(String departmentName);

    Employee findByEmail(String email);
    @Query("SELECT e FROM Employee e WHERE e.name = :name")
    List<Employee> findEmployeesByName(@Param("name") String name);
    Page<Employee> findAll(Pageable pageable);
    Page<Employee> findByNameContaining(String keyword, Pageable pageable);

    @Query("SELECT e FROM Employee e")
    List<EmployeeProjection> findEmployeeProjections();

    @Query("SELECT new com.example.EmployeeManagementSystem.entity.EmployeeDTO(e.name, e.email) FROM Employee e")
    List<EmployeeDTO> findEmployeeDTOs();
    
}



