package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.Department;
import com.example.EmployeeManagementSystem.entity.DepartmentDTO;
import com.example.EmployeeManagementSystem.entity.DepartmentProjection;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department,Long> {
    
    List<Department> findByNameContaining(String keyword);

    @Query("SELECT d FROM Department d")
    List<DepartmentProjection> findDepartmentProjections();

    @Query("SELECT new com.yourcompany.yourproject.model.DepartmentDTO(d.name) FROM Department d")
    List<DepartmentDTO> findDepartmentDTOs();
}

