package com.example.EmployeeManagementSystem.entity;


public class DepartmentDTO {

    private String name;

    public DepartmentDTO(String name) {
        this.name = name;
    }

    // Getter and Setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
