public class TaskManagementSystem {
    private TaskNode head;

    public TaskManagementSystem() {
        this.head = null;
    }

    // Add task
    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        if (head == null) {
            head = newNode;
        } else {
            TaskNode temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Search task by ID
    public Task searchTaskById(int taskId) {
        TaskNode temp = head;
        while (temp != null) {
            if (temp.task.taskId == taskId) {
                return temp.task;
            }
            temp = temp.next;
        }
        return null;
    }

    // Traverse all tasks
    public void traverseTasks() {
        TaskNode temp = head;
        while (temp != null) {
            System.out.println(temp.task);
            temp = temp.next;
        }
    }

    // Delete task by ID
    public void deleteTaskById(int taskId) {
        if (head == null) {
            System.out.println("Task list is empty.");
            return;
        }

        if (head.task.taskId == taskId) {
            head = head.next;
            return;
        }

        TaskNode temp = head;
        while (temp.next != null && temp.next.task.taskId != taskId) {
            temp = temp.next;
        }

        if (temp.next == null) {
            System.out.println("Task not found.");
        } else {
            temp.next = temp.next.next;
        }
    }

    public static void main(String[] args) {
        TaskManagementSystem system = new TaskManagementSystem();

        Task task1 = new Task(1, "Task One", "Pending");
        Task task2 = new Task(2, "Task Two", "In Progress");
        Task task3 = new Task(3, "Task Three", "Completed");
        Task task4 = new Task(4, "Task Four", "Pending");
        Task task5 = new Task(5, "Task Five", "In Progress");

        system.addTask(task1);
        system.addTask(task2);
        system.addTask(task3);
        system.addTask(task4);
        system.addTask(task5);

        System.out.println("All tasks:");
        system.traverseTasks();

        System.out.println("\nSearch task with ID 3:");
        Task searchedTask = system.searchTaskById(3);
        if (searchedTask != null) {
            System.out.println(searchedTask);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("\nDeleting task with ID 2:");
        system.deleteTaskById(2);

        System.out.println("All tasks after deletion:");
        system.traverseTasks();
    }
}

