public class LinearSearch {
    public static Product linearSearch(Product[] products, String targetName) {
        for (Product product : products) {
            if (product.getProductName().equals(targetName)) {
                return product;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
                new Product(1, "Laptop", "Electronics"),
                new Product(2, "Mouse", "Electronics"),
                new Product(3, "Keyboard", "Electronics")
        };

        Product result = linearSearch(products, "Monitor");
        if (result != null) {
            System.out.println("Product found: " + result.getProductName());
        } else {
            System.out.println("Product not found");
        }
    }
}

