import java.util.Arrays;

public class LibraryBinary {
    public static Book binarySearchByTitle(Book[] books, String title) {
        int left = 0;
        int right = books.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].title.compareToIgnoreCase(title);

            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
                new Book(1, "1984", "George Orwell"),
                new Book(2, "Moby Dick", "Herman Melville"),
                new Book(3, "The Catcher in the Rye", "J.D. Salinger"),
                new Book(4, "The Great Gatsby", "F. Scott Fitzgerald"),
                new Book(5, "To Kill a Mockingbird", "Harper Lee")
        };

        // Ensure the array is sorted by title for binary search
        Arrays.sort(books, (b1, b2) -> b1.title.compareToIgnoreCase(b2.title));

        Book foundBook = binarySearchByTitle(books, "1984");
        if (foundBook != null) {
            System.out.println("Found book: " + foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }
}
