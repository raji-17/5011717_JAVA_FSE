public class LibraryLinear {
    public static Book linearSearchByTitle(Book[] books, String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
                new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
                new Book(2, "1984", "George Orwell"),
                new Book(3, "To Kill a Mockingbird", "Harper Lee"),
                new Book(4, "The Catcher in the Rye", "J.D. Salinger"),
                new Book(5, "Moby Dick", "Herman Melville")
        };

        Book foundBook = linearSearchByTitle(books, "1984");
        if (foundBook != null) {
            System.out.println("Found book: " + foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }
}
