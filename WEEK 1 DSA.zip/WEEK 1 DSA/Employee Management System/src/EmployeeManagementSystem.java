public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add employee
    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        } else {
            System.out.println("Employee list is full.");
        }
    }

    // Search employee by ID
    public Employee searchEmployeeById(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse all employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete employee by ID
    public void deleteEmployeeById(int employeeId) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId == employeeId) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            for (int i = index; i < size - 1; i++) {
                employees[i] = employees[i + 1];
            }
            employees[--size] = null;
        } else {
            System.out.println("Employee not found.");
        }
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        Employee emp1 = new Employee(1, "Alice", "Manager", 60000);
        Employee emp2 = new Employee(2, "Bob", "Developer", 50000);
        Employee emp3 = new Employee(3, "Charlie", "Designer", 55000);
        Employee emp4 = new Employee(4, "Dave", "Tester", 45000);
        Employee emp5 = new Employee(5, "Eve", "Admin", 40000);

        system.addEmployee(emp1);
        system.addEmployee(emp2);
        system.addEmployee(emp3);
        system.addEmployee(emp4);
        system.addEmployee(emp5);

        System.out.println("All employees:");
        system.traverseEmployees();

        System.out.println("\nSearch employee with ID 3:");
        Employee searchedEmp = system.searchEmployeeById(3);
        if (searchedEmp != null) {
            System.out.println(searchedEmp);
        } else {
            System.out.println("Employee not found.");
        }

        System.out.println("\nDeleting employee with ID 2:");
        system.deleteEmployeeById(2);

        System.out.println("All employees after deletion:");
        system.traverseEmployees();
    }
}
