package com.example.bookstoreapi.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.List;
import com.example.bookstoreapi.controller.BookController;

@Component
public class BookstoreMetrics {

    private final MeterRegistry meterRegistry;
    private final BookController bookController;

    public BookstoreMetrics(MeterRegistry meterRegistry, BookController bookController) {
        this.meterRegistry = meterRegistry;
        this.bookController = bookController;
    }

    @PostConstruct
    public void init() {
        meterRegistry.gauge("bookstore.books.total", bookController.getAllBooks(), List::size);
    }
}
