package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @PostMapping("/login")
    public String login(@RequestParam String username) {
        // Validate user credentials (add your own user validation logic here)
        return jwtTokenProvider.createToken(username);
    }
}
