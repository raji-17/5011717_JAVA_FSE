public class StrategyPatternExample {

    interface PaymentStrategy {
        void pay(int amount);
    }

    static class CreditCardPayment implements PaymentStrategy {
        private String name;
        private String cardNumber;

        public CreditCardPayment(String name, String cardNumber) {
            this.name = name;
            this.cardNumber = cardNumber;
        }

        @Override
        public void pay(int amount) {
            System.out.println("Paid " + amount + " using Credit Card.");
        }
    }

    static class PayPalPayment implements PaymentStrategy {
        private String email;

        public PayPalPayment(String email) {
            this.email = email;
        }

        @Override
        public void pay(int amount) {
            System.out.println("Paid " + amount + " using PayPal.");
        }
    }

    static class PaymentContext {
        private PaymentStrategy paymentStrategy;

        public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
            this.paymentStrategy = paymentStrategy;
        }

        public void executePayment(int amount) {
            paymentStrategy.pay(amount);
        }
    }

    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        PaymentStrategy creditCard = new CreditCardPayment("John Doe", "1234-5678-9876-5432");
        PaymentStrategy paypal = new PayPalPayment("john.doe@example.com");

        context.setPaymentStrategy(creditCard);
        context.executePayment(100);

        context.setPaymentStrategy(paypal);
        context.executePayment(200);
    }
}
